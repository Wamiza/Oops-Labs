#include <iostream>
using namespace std;

class BoardMarker {
   private:	
	string company;
	string colour;
	bool refillable;
	bool inkStatus;
	
  public:
  	
  	BoardMarker(){
	  }
	  
  	BoardMarker( string c, string cl, bool r, bool iS) {
  		company=c;
  		colour=cl;
  		refillable=r;
  		inkStatus=iS;
	  }
	  
    void setCompany(string c){
    	company=c;
	}
	 void setColour(string cl){
	 	colour=cl;
	}
	void setRefillable(bool r) {
		refillable=r;
	}
	void setInkStatus(bool iS) {
		inkStatus=iS;
	}
	
	string getCompany() {
		return company;
	}
	string getColour() {
		return colour;
	}
	bool getRefillable() {
		return refillable;
	}
	bool getInkStatus(){
		return inkStatus;
	}
	
	void write() {
		if(!inkStatus) {
			cout<<"Writing is not Possible";
		}
		else{
			cout<<"Proceed with writing with " << colour<< " colour , "<< company<<" company marker ";
		}
	}
	
	void refill() {
		if(!refillable){
			cout<<"Marker can not be refilled";
		}
		else if(refillable== true && !inkStatus){
			cout<<"Insufficient Ink";
		}
		else {
			cout<<"refilling";
		}
	}
};

int main() {
	BoardMarker b1("dollar","black",true, true);
	b1.getCompany();
	b1.getColour();
	b1.getInkStatus();
	b1.getRefillable();
	b1.refill();
	cout<<"\n";
	b1.write();
	return 0;
}