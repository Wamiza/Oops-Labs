#include <iostream>
using namespace std;

class WaterBottle {
private:
    string company;
    string color;
    double capacityML;  
    double currentWaterML;  

public:
    void setCompany(string C) {
        company = C;
    }
    void setColor(string Cl) {
        color = Cl;
    }
    void setCapacityInML(double capML) {
        capacityML = capML;
        currentWaterML = capML;  
    }

    string getCompany() {
        return company;
    }
    string getColor() {
        return color;
    }
    double getCapacityInML() {
        return capacityML;
    }
    double getCurrentWaterInML() {
        return currentWaterML;
    }
    double getCurrentWaterInL() {
        return currentWaterML / 1000.0; 
    }
    void drinkWater(double drankML) {
        if (drankML > currentWaterML) {
            cout << "Not enough water in the bottle!"<< endl;
        }
		else {
            currentWaterML -= drankML;
            cout << "You drank " << drankML << " mL of water. Remaining: " << currentWaterML << " mL (" << getCurrentWaterInL() << " L)." << endl;
        }
    }
};

int main() {
    WaterBottle wb;
    string company, color;
    double capacity, drank;

    cout << "Enter the water bottle company: ";
    cin >> company;
    wb.setCompany(company);

    cout << "Enter the water bottle color: ";
    cin >> color;
    wb.setColor(color);

    cout << "Enter the water bottle capacity in mL: ";
    cin >> capacity;
    wb.setCapacityInML(capacity);

    cout << "Water Bottle Details:" << endl;
    cout << "Company: " << wb.getCompany() << endl;
    cout << "Color: " << wb.getColor() << endl;
    cout << "Capacity: " << wb.getCapacityInML() << " mL (" << wb.getCurrentWaterInL() << " L)" << endl;

    cout << "Enter the amount of water you drank in mL: "<<endl;
    cin >> drank;
    wb.drinkWater(drank);

    return 0;
}
