#include <iostream>
using namespace std;

class StationaryShop {
private:
    string items[100];
    double price[100];
    int itemCount;

public:
    StationaryShop() : itemCount(0) {}

    void addItem() {
        if (itemCount >= 100) {
            cout << "Item capacity is full" << endl;
            return;
        }
        cout << "Enter the name of item: ";
        cin.ignore();
        getline(cin, items[itemCount]);

        cout << "Enter the item's price: ";
        cin >> price[itemCount];

        itemCount++;
        cout << "Item added successfully!" << endl;
    }

    void display() {
        if (itemCount == 0) {
            cout << "No items available in the shop." << endl;
            return;
        }
        for (int i = 0; i < itemCount; i++) {
            cout << i + 1 << ". " << items[i] << " - Rs" << price[i] << endl;
        }
    }

    void edit() {
        if (itemCount == 0) {
            cout << "No items available in the shop to edit." << endl;
            return;
        }
        
        display();
        int choice;
        cout << "Enter the number of the item to edit: ";
        cin >> choice;
        cin.ignore(); 

        if (choice < 1 || choice > itemCount) {
            cout << "Invalid Choice!" << endl;
            return;
        }

        cout << "Enter new name for " << items[choice - 1] << ": ";
        getline(cin, items[choice - 1]);

        cout << "Enter new price for " << items[choice - 1] << ": ";
        cin >> price[choice - 1];

        cout << "Item updated successfully!" << endl;
    }

    void generateReceipt() {
        if (itemCount == 0) {
            cout << "No items available in the shop." << endl;
            return;
        }

        display();

        double totalCost = 0.0;
        string purchasedItems[100];
        double purchasedPrices[100];
        int purchasedQuantities[100];
        int purchaseCount = 0;

        while (true) {
            int itemNumber, quantity;
            cout << "Enter the item number to purchase (0 to finish): ";
            cin >> itemNumber;

            if (itemNumber == 0) 
                break;

            if (itemNumber < 1 || itemNumber > itemCount) {
                cout << "Invalid item selection." << endl;
                continue;
            }

            cout << "Enter quantity for " << items[itemNumber - 1] << ": ";
            cin >> quantity;

            if (quantity <= 0) {
                cout << "Invalid quantity." << endl;
                continue;
            }

            purchasedItems[purchaseCount] = items[itemNumber - 1];
            purchasedPrices[purchaseCount] = price[itemNumber - 1];
            purchasedQuantities[purchaseCount] = quantity;
            totalCost += price[itemNumber - 1] * quantity;

            purchaseCount++;
        }

        if (purchaseCount == 0) {
            cout << "No items purchased. Receipt not generated." << endl;
            return;
        }

        cout << "----------> RECEIPT <----------" << endl;
        for (int i = 0; i < purchaseCount; i++) {
            cout << purchasedItems[i] << "\t\t" << purchasedQuantities[i] << "\tRs"
                 << purchasedPrices[i] << "\tRs" << (purchasedPrices[i] * purchasedQuantities[i]) << endl;
        }
        cout << "----------------------------" << endl;
        cout << "Total Amount: Rs" << totalCost << endl;
        cout << "<----------------------------->" << endl;
    }
};

int main() {
    StationaryShop shop;
    int choice;

    while (true) {
        cout << "\nMenu:\n";
        cout << "1. Add Item\n";
        cout << "2. Display Items\n";
        cout << "3. Edit Item\n";
        cout << "4. Generate Receipt\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                shop.addItem();
                break;
            case 2:
                shop.display();
                break;
            case 3:
                shop.edit();
                break;
            case 4:
                shop.generateReceipt();
                break;
            case 5:
                cout << "Exiting program. Thank you!" << endl;
                return 0;
            default:
                cout << "Invalid choice! Please enter a valid option." << endl;
        }
    }
}
