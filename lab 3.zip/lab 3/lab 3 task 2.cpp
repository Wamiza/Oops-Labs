#include <iostream>
using namespace std;

 class Circle {
  private:
 	double radius;
 	
  public:
  	double pi=3.14159;
  	double area;
  	double circumference;
  	double diameter;
 	
  	void setRadius(double r) {
  		radius=r;
	  }
	double getRadius() {
		return radius;
	}
	double getArea() {
		area= pi*radius*radius;
		cout<<"Area of the circle is : "<<area<< endl;
	}
	double getDiameter() {
		diameter= radius*2;
		cout<<"Diameter of the circle is : "<<diameter<< endl;
	}
	double getCircumference() {
		circumference= 2*pi*radius;
		cout<<"Circumference of the circle is : "<<circumference<< endl;
	}
 };
 
 int main() {
 	double radius;
 	Circle C;

 	cout<<"Enter the radius of the Circle : "<<endl;
 	cin>>radius;
 	
 	C.setRadius(radius);
 	C.getArea();
 	C.getDiameter();
 	C.getCircumference();
 	
 	return 0;
 }