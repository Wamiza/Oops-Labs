#include "Employee.h"
using namespace std;

void Employee::get_data() {
    cout << "Enter Employee Name: "<<endl;
    getline(std::cin, name);
    cout << "Enter Monthly Salary: "<<endl;
    cin >> salary;
    cout << "Enter Tax Percentage (e.g., 2 for 2%): "<<endl;
    cin >> taxPercentage;
    cin.ignore(); 
}

double Employee::Salary_after_tax() {
    return salary - (salary * (taxPercentage / 100));
}

void Employee::update_tax_percentage(double newTax) {
    taxPercentage = newTax;
}

void Employee::display() {
    cout << "Employee: " << name;
    cout << "Monthly Salary: $" << salary<< endl;
    cout << "Tax Percentage: " << taxPercentage << "%"<<endl;
    cout << "Salary After Tax: $" << Salary_after_tax() << endl;
}
