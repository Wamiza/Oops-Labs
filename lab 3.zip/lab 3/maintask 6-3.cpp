#include "Employee.h"
using namespace std;

int main() {
    Employee emp1, emp2, emp3;

    cout << "Enter details for Employee 1:"<<endl;
    emp1.get_data();
    cout << "Enter details for Employee 2:"<<endl;
    emp2.get_data();
    cout << "Enter details for Employee 3:"<<endl;
    emp3.get_data();

    std::cout << "-----> Initial Salary Details <-----"<<endl;
    emp1.display();
    emp2.display();
    emp3.display();

    double newTax;
    cout << "Enter new tax percentage for Employee 1: "<<endl;
    cin >> newTax;
    emp1.update_tax_percentage(newTax);

    cout << "-----> Updated Salary Details <-----"<<endl;
    emp1.display();

    return 0;
}
