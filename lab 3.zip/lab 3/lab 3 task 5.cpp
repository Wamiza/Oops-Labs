#include <iostream>
#include <string>
using namespace std;

class Employee {
private:
    string name;
    double salary;
    double taxPercentage;

public:
    void get_data() {
        cout << "Enter Employee Name: ";
        getline(std::cin, name);
        cout << "Enter Monthly Salary: ";
        cin >> salary;
        cout << "Enter Tax Percentage (e.g., 2 for 2%): ";
        cin >> taxPercentage;
        cin.ignore();
    }

    double Salary_after_tax() {
        return salary - (salary * (taxPercentage / 100));
    }

    void update_tax_percentage(double newTax) {
        taxPercentage = newTax;
    }

    void display() {
        cout << "Employee: " << name<<endl;
        cout << "Monthly Salary: $" << salary<<endl;
        cout << "Tax Percentage: " << taxPercentage << "%"<<endl;
        cout << "Salary After Tax: $" << Salary_after_tax() <<endl;
    }
};

int main() {
    Employee emp1, emp2, emp3;

    cout << "Enter details for Employee 1 : "<<endl;
    emp1.get_data();
    cout << "Enter details for Employee 2 : "<<endl;
    emp2.get_data();
    cout << "Enter details for Employee 3 : "<<endl;
    emp3.get_data();
    cout << "-----> Initial Salary Details <-----";
    emp1.display();
    emp2.display();
    emp3.display();

    double newTax;
    cout << "Enter new tax percentage for Employee 1 : "<<endl;
    cin >> newTax;
    emp1.update_tax_percentage(newTax);
    emp2.update_tax_percentage(newTax);
    emp3.update_tax_percentage(newTax);

    cout << "-----> Updated Salary Details <-----"<<endl;
    emp1.display();
    emp2.display();
    emp3.display();

    return 0;
}
