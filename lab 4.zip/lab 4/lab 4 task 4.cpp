#include <iostream>
#include <string>
using namespace std;

class CricketPlayer {
private:
    string name;
    int jerseyNumber;
    double battingAverage;
    int totalRuns;
    int totalInnings;

public:
    CricketPlayer(string name, int jerseyNumber, double battingAverage) {
        this->name = name;
        this->jerseyNumber = jerseyNumber;
        this->battingAverage = battingAverage;
        this->totalRuns = battingAverage * 10;  
        this->totalInnings = 10; 
    }

    CricketPlayer& improveAverage(double runs) {
        battingAverage += runs / 10;
        return *this; 
    }

    void playMatch(int runsScored) {
        totalRuns += runsScored;
        totalInnings++;
        battingAverage = (double)totalRuns / totalInnings;
    }

    void displayPlayerStats() const {
        cout<<"Player: "<<name<<endl<<"Jersey Number: "<<jerseyNumber<<endl<<"Batting Average: "<<battingAverage<<endl<<"Total Runs: "<<totalRuns<<endl<<"Total Innings: "<<totalInnings<<endl;;
        cout << "Commentary: This batting average is more consistent than Karachi's weather!"<<endl;
    }
};

int main() {
    CricketPlayer babar("Babar Azam", 56, 45.5);
    CricketPlayer rizwan("Muhammad Rizwan", 16, 42.8);
    CricketPlayer saim("Saim Ayub", 23, 32.6);

    babar.playMatch(100); 
    rizwan.playMatch(75); 
    saim.playMatch(5);  

    babar.improveAverage(10).improveAverage(5);
    rizwan.improveAverage(8);
    saim.improveAverage(12);

    babar.displayPlayerStats();
    rizwan.displayPlayerStats();
    saim.displayPlayerStats();

    return 0;
}
