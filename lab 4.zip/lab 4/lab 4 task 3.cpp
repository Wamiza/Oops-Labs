#include <iostream>
using namespace std;

class SmartDevice {
private:
    string name;
    string type;
    bool status;

public:
    SmartDevice() : name("Unknown"), type("Unknown"), status(false) {}

    SmartDevice(string n, string t, bool s) {
        name = n;
        type = t;
        status = s;
        if (status == true) { 
            cout << name << " is activated. Status: " << (status ? "ON" : "OFF") << endl;
        }
    }

    void On() {
        status = true;
        cout << name << " is On" << endl;
    }

    void Off() { 
        status = false;
        cout << name << " is Off" << endl;
    }

    ~SmartDevice() {
        cout << name << " (" << type << ") You Let Me Die ! GOODBYE" << endl;
    }
};

int main() {
    SmartDevice* light = new SmartDevice("Bulb", "Smart Light", true);
    light->Off();

    SmartDevice* vacuum = new SmartDevice("Robo", "Vacuum", true);
    vacuum->On();
    vacuum->Off();

    delete light;
    delete vacuum;

    return 0;
}