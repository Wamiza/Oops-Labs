#include <iostream>
#include <string>
using namespace std;

class FootballPlayer {
private:
    string playerName;
    string position;
    int goalCount;

public:
    FootballPlayer() {
        playerName = "Unknown Player";
        position = "Benchwarmer";
        goalCount = 0;
    }

    FootballPlayer(string pN, string p, int gC) {
        playerName = pN;
        position = p;
        goalCount = gC;
    }

    FootballPlayer(string pN, int gC = 10, string p = "Midfielder") {
        playerName = pN;
        position = p;
        goalCount = gC;
    }

    FootballPlayer(const FootballPlayer &fp) {
        playerName = fp.playerName;
        position = fp.position;
        goalCount = fp.goalCount;
    }

    void boostGoals(int extraGoals) {
        goalCount += extraGoals;
    }

    void display() const {
        cout << "Player Name: " << playerName << endl;
        cout << "Position: " << position << endl;
        cout << "Goal Count: " << goalCount << endl;
        cout << "Commentary: " << playerName << " is on fire! The Ballon d'Or! is calling!" << endl;
    }
};

int main() {
    FootballPlayer Fb1("Lionel Messi", "Forward", 800);
    Fb1.display();

    FootballPlayer Fb2("Neymar");
    Fb2.display();
    
    FootballPlayer Fb3 = Fb1;
    Fb3.display();

    Fb1.boostGoals(5); 
    Fb2.boostGoals(3); 

    Fb1.display();
    Fb2.display();

    return 0;
}