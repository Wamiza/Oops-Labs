#include <iostream>
using namespace std;

void add(int* a, int* b, int* result) {
    *result = *a + *b;
}

void subtract(int* a, int* b, int* result) {
    *result = *a - *b;
}

void multiply(int* a, int* b, int* result) {
    *result = (*a) * (*b);
}

void divide(int* a, int* b, float* result) {
    if (*b != 0)
        *result = (float)(*a) / (*b);
    else
        cout << "Oops! Division by zero is not allowed."<<endl;
}

int main() {
    int num1, num2, result;
    char choice;
    float divResult;

    cout << "Enter first number: "<<endl;
    cin >> num1;
    cout << "Enter second number: "<<endl;
    cin >> num2;

    do {
        cout << "+ for Addition"<<endl<< "- for Subtraction"<<endl<< "* for Multiplication "<<endl << "/ for Division"<<endl<< "1 for exit"<<endl;
        cin >> choice;

        if (choice=='+') {
                add(&num1, &num2, &result);
                cout << "The sum is: " << result << endl;
            }
        else if (choice=='-') {
                subtract(&num1, &num2, &result);
                cout << "The difference is: " << result << endl;
            }
        else if (choice=='*') {            
                multiply(&num1, &num2, &result);
                cout << "The product is: " << result << endl;
            }
        else if (choice=='/') {
                divide(&num1, &num2, &divResult);
                if (num2 != 0) 
                    cout << "The quotient is: " << divResult << endl;
            }
        else if (choice=='1' ) {
                cout << "Exiting the calculator....!"<< endl;
                return 0;
            }
        else {
                cout << "Invalid choice."<< endl;
        }
    } 
	while (choice != 1);
    return 0;
}
