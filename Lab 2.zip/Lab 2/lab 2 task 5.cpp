#include <iostream>
using namespace std;

int** Creatematrix(int rows, int cols) {
    int** matrix = new int*[rows];
    for (int i = 0; i < rows; i++) {
        matrix[i] = new int[cols];
    }
    return matrix;
}

void input(int** matrix, int rows, int cols) {
    cout << "Enter the elements:"<<endl;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            cin >> matrix[i][j];
        }
    }
}

void display(int** matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            cout << matrix[i][j] << " "<<endl;
        }
        cout << endl;
    }
}

int** add(int** a, int** b, int rows, int cols) {
    int** result = Creatematrix(rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            result[i][j] = a[i][j] + b[i][j];
        }
    }
    return result;
}

int** subtract(int** a, int** b, int rows, int cols) {
    int** result = Creatematrix(rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            result[i][j] = a[i][j] - b[i][j];
        }
    }
    return result;
}

int** multiply(int** a, int** b, int rowsa, int colsa, int colsb) {
    int** result = Creatematrix(rowsa, colsb);
    for (int i = 0; i < rowsa; i++) {
        for (int j = 0; j < colsb; j++) {
            result[i][j] = 0;
            for (int k = 0; k < colsa; k++) {
                result[i][j] += a[i][k] * b[k][j];
            }
        }
    }
    return result;
}

void deleteMatrix(int** matrix, int rows) {
    for (int i = 0; i < rows; i++) {
        delete[] matrix[i];
    }
    delete[] matrix;
}

int main() {
    int rowsa, colsa, rowsb, colsb;

    cout << "Enter the rows and columns of matrix A: "<<endl;
    cin >> rowsa >> colsa;
    cout << "Enter the rows and columns of matrix B: "<<endl;
    cin >> rowsb >> colsb;

    int** a = Creatematrix(rowsa, colsa);
    int** b = Creatematrix(rowsb, colsb);

    cout << "Enter the elements of matrix A:"<<endl;
    input(a, rowsa, colsa);
    cout << "Enter the elements of matrix B:"<<endl;
    input(b, rowsb, colsb);

    if (rowsa == rowsb && colsa == colsb) {
        int** sum = add(a, b, rowsa, colsa);
        cout << "Matrix after Addition:"<<endl;
        display(sum, rowsa, colsa);
        deleteMatrix(sum, rowsa);

        int** difference = subtract(a, b, rowsa, colsa);
        cout << "Matrix after Subtraction:"<<endl;
        display(difference, rowsa, colsa);
        deleteMatrix(difference, rowsa);
    } 
	else {
        cout << "Addition and subtraction not possible"<<endl;
    }

    if (colsa == rowsb) {
        int** product = multiply(a, b, rowsa, colsa, colsb);
        cout << "Matrix after Multiplication:"<<endl;
        display(product, rowsa, colsb);
        deleteMatrix(product, rowsa);
    } 
	else {
        cout << "Multiplication not possible."<<endl;
    }

    deleteMatrix(a, rowsa);
    deleteMatrix(b, rowsb);
    cout << "Memory cleaned up successfully. Exiting program.\n";

    return 0;
}