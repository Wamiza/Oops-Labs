#include <iostream>
using namespace std;

class HungryArray {
private:
    int* data;
    int capacity;
    int size;

    void resize(int newCapacity) {
        int* newData = new int[newCapacity];
        for (int i = 0; i < size; i++) {
            newData[i] = data[i];
        }
        delete[] data;
        data = newData;
        capacity = newCapacity;
    }

public:
    HungryArray() : capacity(5), size(0) {
        data = new int[capacity];
    }

    ~HungryArray() {
        delete[] data;
    }

    void add(int value) {
        if (size == capacity) {
            resize(capacity * 2); 
        }
        data[size++] = value;
    }

    void shrinkToFit() {
        if (size < capacity) {
            resize(size);
        }
    }

    void print() {
        for (int i = 0; i < size; i++) {
            cout << data[i] << " ";
        }
    }
};

int main() {
    HungryArray arr;
    int n, value;
    
    cout << "Enter the number of elements: ";
    cin >> n;
    
    cout << "Enter the elements: " << endl;
    for (int i = 0; i < n; i++) {
        cin >> value;
        arr.add(value);
    }
    
    cout << "Array before shrinking: " << endl;
    arr.print();
    arr.shrinkToFit();
    cout << "\nArray after shrinking: " << endl;
    arr.print();
    
    return 0;
}
