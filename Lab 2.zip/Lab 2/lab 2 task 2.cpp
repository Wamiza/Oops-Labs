#include <iostream>
using namespace std;

 struct product {
 	int id;
 	string name;
 	float price;
 	int quantity;
 	
 };
 
 class Manage{
 	private:
 		product inventory[100];
 		int id=1;
 		
 	public:
 void newProduct(string name, float price, int quantity) {
 	product newProduct= {id, name, price, quantity};
 	inventory[id]= newProduct;
 	cout<<"Product added Sucessfully"<<endl;
 	id++;
 }
 
 void display(int id) {
 	if (id < this->id && id >= 0) {
        product p = inventory[id];
        cout << "Product ID: " << p.id << endl;
        cout << "Name: " << p.name << endl;
        cout << "Price: " << p.price << endl;
        cout << "Quantity: " << p.quantity << endl;
        }
		else {
            cout << "Product not found!" << endl;
        }
 }
 
 void update(int id, float newPrice, int newQuantity) {
     if (id < this->id && id >= 0) {
        inventory[id].price = newPrice;
        inventory[id].quantity = newQuantity;
        cout << "Product updated successfully" << endl;
        }
		else {
            cout << "Product not found!" << endl;
        }
 }
 
 void remove(int id) {
    if (id < this->id) {
    for (int i = id; i < this->id - 1; i++) {
    inventory[i] = inventory[i + 1];
    }
    this->id--; 
    cout << "Product removed successfully." << endl;
    } 
	else {
            cout << "Product not found!" << endl;
        }
    }
 };
 
 
 int main(){
 	Manage m;
 	
    int choice, id;
    string name;
 	float price;
 	int quantity;
 	
 	do {
 	cout << "Enter 1 to Add Product" <<endl <<"Enter 2 to Display Product" << endl << "Enter 3 to Update Product" << endl << "Enter 4 to Remove Product"<< endl << "Enter 5 to Exit"<< endl;
 	cin>> choice; 
 	
 	if(choice==1){
 		cout << "Enter product name: ";
        cin >> name;
        cout << "Enter product price: ";
        cin >> price;
        cout << "Enter product quantity: ";
        cin >> quantity;
        m.newProduct(name, price, quantity);
	 }
	 else if(choice==2){
 	    cout << "Enter product ID to display: ";
        cin >> id;
        m.display(id);
	 }
	  else if(choice==3){
 	   cout << "Enter product ID to update: ";
       cin >> id;
       cout << "Enter new price: ";
       cin >> price;
       cout << "Enter new quantity: ";
       cin >> quantity;
       m.update(id, price, quantity);
	 }
	  else if(choice==4){
        cout << "Enter product ID to remove: ";
        cin >> id;
        m.remove(id);
	 }
	  else if(choice==5){
 		return 0;
	 }
	 else {
            cout << "Invalid choice, please try again." << endl;
        }
    }
 	while(choice!=5);
	 return 0; 	 	
 }
