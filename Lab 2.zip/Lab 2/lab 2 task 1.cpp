#include <iostream>
using namespace std;

struct Book {
    string title;
    string author;
    int year;
    string genre;
};

const int MAX_BOOKS = 150;
Book books[MAX_BOOKS];
int bookCount = 0;

void addBook() {
    if (bookCount >= MAX_BOOKS) {
        cout << "Library is full."<<endl;
        return;
    }

    cout << "Enter book title: "<<endl;
    cin.ignore(); 
    getline(cin, books[bookCount].title);
    cout << "Enter author: "<<endl;
    getline(cin, books[bookCount].author);
    cout << "Enter publication year: "<<endl;
    cin >> books[bookCount].year;
    cin.ignore(); 
    cout << "Enter genre: "<<endl;
    getline(cin, books[bookCount].genre);
    bookCount++;
    cout << "Book added successfully!"<<endl;
}

void displayBooks() {
    if (bookCount == 0) {
        cout << "No books available."<<endl;
        return;
    }
    for (int i = 0; i < bookCount; i++) {
        cout << "Book: " << i + 1 <<endl<< "Title: " << books[i].title <<endl<< "Author: " << books[i].author <<endl<< "Year: " << books[i].year<<endl<< "Genre: " << books[i].genre <<endl;
    }
}

void searchBook() {
    if (bookCount == 0) {
        cout << "No books available to search."<<endl;
        return;
    }
    string query;
    cout << "Enter title or author to search: "<<endl;
    cin.ignore();
    getline(cin, query);

    for (int i = 0; i < bookCount; i++) {
        if (books[i].title == query || books[i].author == query) {
            cout << "\nFound Book:"<<endl<< "Title: " << books[i].title<<endl<< "Author: " << books[i].author <<endl<< "Year: " << books[i].year <<endl<< "Genre: " << books[i].genre <<endl;
            return;
        }
    }
    cout << "Book not found."<<endl;
}

void updateBook() {
    if (bookCount == 0) {
        cout << "No books available to update."<<endl;
        return;
    }

    string query;
    cout << "Enter title of book to update: "<<endl;
    cin.ignore();
    getline(cin, query);

    for (int i = 0; i < bookCount; i++) {
        if (books[i].title == query) {
            cout << "Enter new title: "<<endl;
            getline(cin, books[i].title);
            cout << "Enter new author: "<<endl;
            getline(cin, books[i].author);
            cout << "Enter new publication year: "<<endl;
            cin >> books[i].year;
            cin.ignore();
            cout << "Enter new genre: "<<endl;
            getline(cin, books[i].genre);
            cout << "Book updated successfully!"<<endl;
            return;
        }
    }
    cout << "Book not found."<<endl;
}

int main() {
    int choice;
    do {
        cout << "Enter 1. Add Book"<<endl<<"2. Display Books"<<endl<<"3. Search Book"<<endl<<"4. Update Book"<<endl<<"5. Exit";
        cin >> choice;

        switch (choice) {
            case 1: addBook(); 
			break;
            case 2: displayBooks(); 
			break;
            case 3: searchBook(); 
			break;
            case 4: updateBook(); 
			break;
            case 5: cout << "Goodbye!"<<endl; 
			break;
            default: cout << "Invalid choice. Try again."<<endl;
        }
    }
	while (choice != 5);

    return 0;
}