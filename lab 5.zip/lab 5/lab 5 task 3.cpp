#include <iostream>
using namespace std;

class Menu{
	public:
		string foodName[100];
		string foodPrice[100];
		int count=0;
		
	void adddish(){
		cout<<"Enter the Dish to add: "<<endl;
		cin>>foodName[i];
		foodPrice[i]=i*50;
		count++;
	}
	void removedish(){
		cout<<"Enter the number of dish to remove: "<<endl;
		foodName[i-1];
		foodPrice[i-1];
	}
	void displayMenu(){
		for(int i=0; i<count; i++){
			cout<<" Dish Name "<<" : Price "<<endl;
			cout<<i<<" "<<foodNmae[i]<<" :  "<<foodPrice[i]<<endl;
		}
	}
};

class Order{
	public:
		double payment;
		Menu menu;
		
		menu.displayMenu();
		
		void order(int choice;) {
		cout<<"Enter the number of dish to select"<<endl;
		cin>>choice;
		
		for(int i=0; i<)
	    }
};