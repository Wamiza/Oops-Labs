#include <iostream>
#include <string>
using namespace std;

class Battery{
	private:
		int capacity;
	public:
	    Battery(int cap){
	    	capacity=cap;
		}
		
		void showDetails() const {
			cout<<"Battery capacity: "<<capacity<<" mAh"<<endl;
		}	
};

class Smartphone{
	private: 
	    string model;
	    Battery battery;
	public:
		Smartphone(string mode, int batteryCapacity) : model(mode), battery(batteryCapacity) {} 

		void showDetails(){
		cout<<"Phone Model: "<<model<<endl;
		battery.showDetails();
	    }
};

int main(){
	Smartphone S1("S23 Ultra",5000);
	S1.showDetails();
	
	return 0;
}