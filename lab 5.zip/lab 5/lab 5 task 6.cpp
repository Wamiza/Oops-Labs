#include <iostream>

using namespace std;

class LoanHelper {
private:
    double loanAmount;
    int months;
    const double interestRate;

public:
    LoanHelper(double amount, int period, double rate) : loanAmount(amount), months(period), interestRate(rate) {
        if (interestRate < 0.0 || interestRate > 0.005) {
            cout << "Invalid interest rate. Must be between 0% and 0.5%." << endl;
            exit(1);
        }
    }

    void calculateMonthlyPayment() const {
        double monthlyPayment = (loanAmount / months) + ((loanAmount * interestRate) / months);
        cout << "You have to pay " << monthlyPayment << " every month for " << months << " months to repay your loan." << endl;
    }
};

int main() {
    LoanHelper loan1(12000, 12, 0.005);
    LoanHelper loan2(5000, 10, 0.003);

    loan1.calculateMonthlyPayment();
    loan2.calculateMonthlyPayment();

    return 0;
}