#include <iostream>

using namespace std;

class Airport {
private:
    string name;
    string location;

public:
    Airport(const string& n, const string& loc) : name(n), location(loc) {}

    void display() const {
        cout << "Airport: " << name << ", Location: " << location << endl;
    }
};

class Flight {
private:
    string flightNumber;
    Airport* departure;
    Airport* destination;
    Airport* currentLocation;

public:
    Flight(const string& fn, Airport* dep, Airport* dest) : flightNumber(fn), departure(dep), destination(dest), currentLocation(dep) {}

    void divert(Airport* newLocation) {
        currentLocation = newLocation;
    }

    void display() const {
        cout << "Flight " << flightNumber << " is currently at ";
        currentLocation->display();
        cout << "Originally from ";
        departure->display();
        cout << "Heading towards ";
        destination->display();
    }
};

int main() {
    Airport karachi("Jinnah International", "Karachi");
    Airport england("Heathrow", "England");
    Airport islamabad("Islamabad International", "Islamabad");

    Flight pk303("PK-303", &karachi, &england);
    pk303.display();

    cout << "\nHijacking occurred! Flight diverted.\n";
    pk303.divert(&islamabad);
    pk303.display();

    return 0;
}